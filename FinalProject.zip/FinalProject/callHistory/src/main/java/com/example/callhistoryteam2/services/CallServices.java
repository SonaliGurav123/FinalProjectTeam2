/*package com.tmsteam2.callHistory.services;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.tmsteam2.callHistory.dao.CallDao;
import com.tmsteam2.callHistory.model.Call;
@Service
public class CallServices {
@Autowired
CallDao callDao;

	public List<Call> getCallByfromId(Integer fid) {
		List<Call> callList=callDao.getCallByfromId(fid);
		return callList;
		
	}

	public List<Call> getCallBytoId(Integer tid) {
		// TODO Auto-generated method stub
		List<Call> callList=callDao.getCallBytoId(tid);
		return callList;
	}

public String addCall(Call call) {
	callDao.save(call);
	return "Added";
}

public   Call getCallId(Integer cid) {
	Optional<Call>  callList=callDao.findById(cid);
	return callList.orElseThrow(()->new RuntimeException("Record not found"));
}

public Call updateCall(Integer callId,Call call) {
	Call call1=callDao.findById(callId).get();
	call1.setTotalTime(call.getTotalTime());
	return callDao.findById(callId).get();
}

public Call deleteCall(Integer callId) {
	Call call1=callDao.findById(callId).get();
	if(call1!=null)
	callDao.deleteById(callId);
	return call1;
}
public List<Call> getAllDetails() {
	// TODO Auto-generated method stub
	List<Call>  callList=callDao.findAll();
	return callList;
}

public List<Call> getCallByplanId(Integer pid) {
	List<Call> callList=callDao.getCallByfromId(pid);
	return callList;
	
}
public List<Call> getCallBytotaltime(Float totalTime) {
	// TODO Auto-generated method stub
	List<Call> callList=callDao.getCallBytotalTime(totalTime);
	return callList;
}
}*/
package com.example.callhistoryteam2.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.callhistoryteam2.dao.CallDao;
import com.example.callhistoryteam2.exception.BadRequestException;
import com.example.callhistoryteam2.exception.CallNotFoundException;
import com.example.callhistoryteam2.model.Call;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CallServices {
    @Autowired
    CallDao callDao;

    public List<Call> getCallByfromId(Integer fid) {
        List<Call> callList = callDao.getCallByfromId(fid);
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No calls found from ID: " + fid);
        }
        return callList;
    }

    public List<Call> getCallBytoId(Integer tid) {
        List<Call> callList = callDao.getCallBytoId(tid);
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No calls found to ID: " + tid);
        }
        return callList;
    }

    public List<Call> getCallByplanId(Integer planId) {
        List<Call> callList = callDao.getCallByplanId(planId);
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No calls found for plan ID: " + planId);
        }
        return callList;
    }
    public String addCall(Call call) {
        if (call == null) {
            throw new BadRequestException("Call object cannot be null");
        }
        
        callDao.save(call);
        return "Added";
    }

    public Call getCallId(Integer cid) {
        Optional<Call> callList = callDao.findById(cid);
        return callList.orElseThrow(() -> new CallNotFoundException("Record not found with ID: " + cid));
    }

    public Call updateCall(Integer callId, Call call) {
        Call existingCall = callDao.findById(callId).orElseThrow(() -> new CallNotFoundException("Call not found with ID: " + callId));
        existingCall.setTotalTime(call.getTotalTime());
        return callDao.save(existingCall);
    }

    public Call deleteCall(Integer callId) {
        Call existingCall = callDao.findById(callId).orElseThrow(() -> new CallNotFoundException("Call not found with ID: " + callId));
        callDao.deleteById(callId);
        return existingCall;
    }

    public List<Call> getAllDetails() {
        List<Call> callList = callDao.findAll();
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No call records found");
        }
        return callList;
    }

	public List<Call> getCallBytotaltime(Float totalTime) {
		// TODO Auto-generated method stub
		List<Call> callList = callDao.getCallBytotalTime(totalTime);
        if (callList.isEmpty()) {
            throw new CallNotFoundException("No calls found with total time: " + totalTime);
        }
        return callList;
    }
	public float getTotalAmountById(Integer fromId ) {
		// TODO Auto-generated method stub
		float callamt = callDao.getTotalAmount(fromId);
        if (callDao.getTotalAmount(fromId) == null) {
            throw new CallNotFoundException("No calls made by customer Id: " + fromId);
        }
        return callDao.getTotalAmount(fromId);
    }
	}




