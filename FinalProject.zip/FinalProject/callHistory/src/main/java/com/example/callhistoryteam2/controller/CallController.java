package com.example.callhistoryteam2.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.callhistoryteam2.model.Call;
import com.example.callhistoryteam2.services.CallServices;




@RestController
public class CallController {
	@Autowired
	CallServices callServices;
	@GetMapping("/getCallByFromid/{fromid}")
	public List<Call> getCallByfromId(@PathVariable Integer fromid) {
		return callServices.getCallByfromId(fromid);
	}
	@GetMapping("/getCallByToid/{toid}")
	public List<Call> getCallBytoId(@PathVariable Integer toid) {
		return callServices.getCallBytoId(toid);
	}
	@GetMapping("/getAllCalldetails")
	public List<Call> getAllDetails1() {
		return callServices.getAllDetails();
	}
	@GetMapping("/getCallByCallid/{callid}")
public Call getCallBycallId(@PathVariable Integer callid) {
		
		return callServices.getCallId(callid);
	}
	@GetMapping("/getCallByTotalTime/{totaltime}")
	public List<Call> getCallBytotaltime(@PathVariable Float totaltime) {
			
			return callServices.getCallBytotaltime(totaltime);
  }
	@GetMapping("/getCallByPlanid/{planId}")
	public List<Call> getCallByplanId(@PathVariable Integer planId) {
		return callServices.getCallByplanId(planId);

	}
@PostMapping("/addCall") 
public String  addcallDetails(@RequestBody	  Call call) {
	    String result= callServices.addCall(call);
	  return  result;

}
@GetMapping("/getCallAmountByCustomerId/{fromId}")
public float getCallAmountByFromId(@PathVariable Integer fromId) {
	float a=callServices.getTotalAmountById(fromId);
	return (float)(a*0.9);
}

/*
@PutMapping("/call") 
public Call updateCallDetails(@PathVariable("callId") Integer callId,@RequestBody Call call) {
	
	return  callServices.updateCall(callId, call); 
}

@DeleteMapping("/call") 
public Call deleteCallDetails(@PathVariable("callId") Integer callId) {
	
	return callServices.deleteCall(callId);
}*/


}

