package com.example.planteam2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.planteam2.dao.PlanDao;
import com.example.planteam2.model.PlanTeam2;

@Service
public class PlanService {
	@Autowired
	PlanDao planDao;
	
	public String addPlan(PlanTeam2 p1)
	{
		planDao.save(p1);
		return "added";
	}

	public List<PlanTeam2> getAll() {
		List<PlanTeam2> p1=planDao.findAll();
		return p1;
	}
    public List<PlanTeam2> getPlanByPname(String pname) {
    	List<PlanTeam2> p2=planDao.findByPname(pname);
		
		return p2;
		
	}
    public List<PlanTeam2> getPlanBypPrice(Integer price) {
 		List<PlanTeam2> p3=planDao.findByPrice(price);
 		
 		return p3;
 	}
    public List<PlanTeam2> getPlanBypDays(Integer days) {
  		List<PlanTeam2> p4=planDao.findByNoOfDays(days);
  		return p4;
  	}

	public List<PlanTeam2> findBytypeOfPlan1(String typeOfPlan) {
		
				return planDao.findBytypeOfPlan(typeOfPlan);
	}

}
