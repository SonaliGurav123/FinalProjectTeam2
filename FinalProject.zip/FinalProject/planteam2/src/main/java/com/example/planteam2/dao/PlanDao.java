package com.example.planteam2.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.planteam2.model.PlanTeam2;

@Repository
public interface PlanDao extends JpaRepository<PlanTeam2,Integer>{
	//@Query("SELECT p FROM PlanTeam p WHERE p.pname = :pname")
	//List<PlanTeam2> getPlanByName(@Param("pname") String pname);
	List<PlanTeam2> findByPname(String pname);

	
	//@Query("SELECT p FROM PlanTeam p WHERE p.price = :price")
	//List<PlanTeam2> getPlanByPrice(@Param("price")Integer price);
	List<PlanTeam2> findByPrice(Integer price);


	//@Query("SELECT p FROM PlanTeam p WHERE p.noOfDays = :days")
	//List<PlanTeam2> getPlanByDays(@Param("days")Integer days);
	List<PlanTeam2> findByNoOfDays(Integer days);

	List<PlanTeam2> findBytypeOfPlan(String typeOfPlan);

}
