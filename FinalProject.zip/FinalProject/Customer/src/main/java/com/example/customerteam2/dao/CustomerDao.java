package com.example.customerteam2.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import org.springframework.stereotype.Repository;

import com.example.customerteam2.model.CustomerTeam2;

@Repository
public interface CustomerDao extends JpaRepository <CustomerTeam2 , Integer>
{
	//@Query("select c from CustomerTeam2 c where c.status=:status")
	//List<CustomerTeam2> findByStatus(@Param("status")String status);
	
	List<CustomerTeam2> findByStatus(String status);

	//@Query("select c from CustomerTeam2 c where c.phNo=:phoneNo")
	//List<CustomerTeam2> findByPhone(@Param("phoneNo")String phoneNo);

	List<CustomerTeam2> findByPhNo(String phoneNo);

	List<CustomerTeam2> findByPlanId(Integer planId);
}
