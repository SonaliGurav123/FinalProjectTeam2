package com.example.customerteam2.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "customers")
public class CustomerTeam2 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer customerId;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(name = "phone_number", length = 15)
    private String phNo;

    @Column(unique = true, nullable = false, length = 255)
    private String email;

    @Column(name = "plan_id")
    private Integer planId;

    @Column(name = "start_date")
    private LocalDate startDuration;

    @Column(name = "end_date")
    private LocalDate endDuration;

    @Column(length = 50)
    private String status;

    // Default constructor
    public CustomerTeam2() {}

    // Parameterized constructor
    public CustomerTeam2(Integer customerId, String name, String phNo, String email, Integer planId, LocalDate startDuration, LocalDate endDuration, String status) {
        this.customerId = customerId;
        this.name = name;
        this.phNo = phNo;
        this.email = email;
        this.planId = planId;
        this.startDuration = startDuration;
        this.endDuration = endDuration; // Calculate end date
        //this.status = status;
    }

 /*   @PrePersist
    @PreUpdate
    private void prePersistOrUpdate() {
        if (startDuration != null) {
            this.endDuration = calculateEndDate(startDuration);
        }
        updateStatus(); // Ensure status is updated before persisting or updating
    }*/

    @PostLoad
    private void updateStatus() {
        if (endDuration != null && endDuration.isBefore(LocalDate.now())) 
        {
            this.status = "Not active";
        }
        if (endDuration != null && endDuration.isAfter(LocalDate.now())) 
        {
            this.status = "Active";    	
        }
    }
/*
    private LocalDate calculateEndDate(LocalDate startDate) {
        return startDate.plusDays(45); // Add 45 days to the start date
    }
*/
    @Override
    public String toString() {
        return "Customer [customerId=" + customerId + ", name=" + name + ", phNo=" + phNo + ", email=" + email
                + ", planId=" + planId + ", startDuration=" + startDuration + ", endDuration=" + endDuration
                + ", status=" + status + "]";
    }

    // Getters and setters
    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhNo() {
        return phNo;
    }

    public void setPhNo(String phNo) {
        this.phNo = phNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getPlanId() {
        return planId;
    }

    public void setPlanId(Integer planId) {
        this.planId = planId;
    }

    public LocalDate getStartDuration() {
        return startDuration;
    }

    public void setStartDuration(LocalDate startDuration) {
        this.startDuration = startDuration;
       // this.endDuration = calculateEndDate(startDuration); // Recalculate end date
    }

    public LocalDate getEndDuration() {
        return endDuration;
    }

    public void setEndDuration(LocalDate endDuration) {
        this.endDuration = endDuration;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
