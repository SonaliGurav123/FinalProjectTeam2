package com.example.customerteam2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.customerteam2.model.CustomerTeam2;
import com.example.customerteam2.service.CustomerService;


@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerservice;
	
	
	@PostMapping("/addCustomer")
	public String addCustomerDetails(@RequestBody CustomerTeam2 customer)
	{
		String result=customerservice.addCustomer(customer);
		return result;
	}
	
	
	@GetMapping("/getAllCustomers")
	public List<CustomerTeam2> displayAllCustomersDetails()
	{
		return customerservice.displayAllCustomers();
	}
	
	@GetMapping("/getCustomerById/{customerId}")
	public CustomerTeam2 getCustomerByCustomerIdDetails(@PathVariable("customerId") Integer customerId)
	{
		return customerservice.displayCustomerById(customerId);
	}
	
	@GetMapping("/getCustomerByPlanId/{planId}")
	public List<CustomerTeam2> getCustomerByPlanId(@PathVariable("planId") Integer planId)
	{
		return customerservice.displayCustomerByPlanId(planId);
	}
	
	@GetMapping("/getCustomerByStatus/{status}")
	public List<CustomerTeam2> getCustomerByStatus(@PathVariable("status") String status)
	{
		return customerservice.displayCustomerByStatus(status);
	}
	
	@GetMapping("/getCustomerByPhoneNo/{phoneNo}")
	public List<CustomerTeam2> getCustomerByphoneNo(@PathVariable("phoneNo") String phoneNo)
	{
		return customerservice.displayCustomerByPhoneNo(phoneNo);
	}

	@GetMapping("/getRemainingDays/{customerId}")
	public String getRemainingDays(@PathVariable("customerId") Integer customerId)
	{
		return customerservice.displayNoOfDaysLeft(customerId);
	}

}
	
	
	

